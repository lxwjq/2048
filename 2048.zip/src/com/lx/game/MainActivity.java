package com.lx.game;

import android.app.Activity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.ScaleAnimation;
import android.view.animation.TranslateAnimation;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

	private static final String TAG = "MainActivity";
	private long mExitTime;
	private TextView tvScore;
	private static MainActivity mainActivity;
	private int score;
	private TextView tvAdd;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_main);

		tvScore = (TextView) findViewById(R.id.tv_score);
		tvAdd = (TextView) findViewById(R.id.tv_add);
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			if ((System.currentTimeMillis() - mExitTime) > 2000) {
				Toast.makeText(this, "再按一次退出程序", Toast.LENGTH_SHORT).show();
				mExitTime = System.currentTimeMillis();
			} else {
				finish();
			}
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}

	public MainActivity() {
		mainActivity = this;
	}

	public static MainActivity getMainActivity() {
		return mainActivity;
	}

	/**
	 * 清空成绩
	 */
	public void clearScore() {
		score = 0;
		showScore();
	}

	/**
	 * 展示成绩
	 */
	public void showScore() {
		tvScore.setText(score + "");
	}

	public void addScore(int x) {
		tvAdd.setVisibility(View.VISIBLE);

		AnimationSet animationSet = new AnimationSet(true);

		TranslateAnimation animation = new TranslateAnimation(
				Animation.RELATIVE_TO_SELF, 0.0f, Animation.RELATIVE_TO_SELF,
				0.0f, Animation.RELATIVE_TO_SELF, 0.5f,
				Animation.RELATIVE_TO_SELF, -1.0f);
		ScaleAnimation scaleAnimation = new ScaleAnimation(1, 0.5f, 1, 0.5f,
				Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF,
				0.0f);

		animationSet.addAnimation(animation);
		animationSet.addAnimation(scaleAnimation);
		animationSet.setFillAfter(true);
		animationSet.setDuration(500);

		tvAdd.setText("+" + x);
		tvAdd.startAnimation(animationSet);
		
		score += x;
		showScore();
		
	}
}
