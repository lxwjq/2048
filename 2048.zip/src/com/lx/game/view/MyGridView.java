package com.lx.game.view;

import java.util.ArrayList;
import java.util.List;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Point;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.GridLayout;

import com.lx.game.MainActivity;

public class MyGridView extends GridLayout {

	private static final String TAG = "MyGridView";
	private Card[][] cardMap = new Card[4][4];
	private List<Point> emptypoint = new ArrayList<Point>();
	private int cardWidth;
	private WindowManager wm;

	public MyGridView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		initView();
	}

	public MyGridView(Context context, AttributeSet attrs) {
		super(context, attrs);
		initView();
	}

	public MyGridView(Context context) {
		super(context);
		initView();
	}

	public void initView() {

		wm = (WindowManager) getContext().getSystemService(
				Context.WINDOW_SERVICE);
		width = wm.getDefaultDisplay().getWidth();
		Log.i(TAG, "width:" + width);
		setColumnCount(4);
		setBackgroundColor(0xffbbada0);

		setOnTouchListener(new View.OnTouchListener() {
			float startX = 0;
			float startY = 0;
			float moveX = 0;
			float moveY;

			@Override
			public boolean onTouch(View v, MotionEvent event) {

				switch (event.getAction()) {
				case MotionEvent.ACTION_DOWN:
					startX = event.getX();
					startY = event.getY();

					break;
				case MotionEvent.ACTION_UP:
					moveX = event.getX() - startX;
					moveY = event.getY() - startY;
					if (Math.abs(moveX) > Math.abs(moveY)) {
						// 在X方向移动
						if (moveX > 5) {
							// 右移动
							rigthMove();
						} else if (moveX < -5) {
							// 向左移动
							leftMove();
						}

					} else {
						// 在Y方向移动
						if (moveY > 5) {
							// 下移动
							downMove();
						} else if (moveY < -5) {
							// 上移动
							upMove();
						}
					}

					break;

				case MotionEvent.ACTION_MOVE:
					break;
				}
				return true;
			}
		});
	}

	/**
	 * 向上移动
	 */
	protected void upMove() {
		boolean isMove = false;
		for (int x = 0; x < 4; x++) {
			for (int y = 0; y < 4; y++) {

				for (int y1 = y + 1; y1 < 4; y1++) {

					if (cardMap[x][y1].getNum() > 0) {

						if (cardMap[x][y].getNum() <= 0) {
							cardMap[x][y].setNum(cardMap[x][y1].getNum());
							cardMap[x][y1].setNum(0);
							y--;
							isMove = true;
						} else if (cardMap[x][y].equals(cardMap[x][y1])) {
							cardMap[x][y].setNum(cardMap[x][y].getNum() * 2);
							cardMap[x][y1].setNum(0);
							MainActivity.getMainActivity().addScore(
									cardMap[x][y].getNum());
							isMove = true;
						}
						break;
					}
				}
			}
		}
		if (isMove) {
			addRandom();
			checkGameEnd();
		}
	}

	/**
	 * 向下移动
	 */
	protected void downMove() {
		boolean isMove = false;
		for (int x = 3; x >= 0; x--) {
			for (int y = 3; y >= 0; y--) {

				for (int y1 = y - 1; y1 >= 0; y1--) {

					if (cardMap[x][y1].getNum() > 0) {

						if (cardMap[x][y].getNum() <= 0) {
							cardMap[x][y].setNum(cardMap[x][y1].getNum());
							cardMap[x][y1].setNum(0);
							y++;
							isMove = true;
						} else if (cardMap[x][y].equals(cardMap[x][y1])) {
							cardMap[x][y].setNum(cardMap[x][y].getNum() * 2);
							cardMap[x][y1].setNum(0);
							MainActivity.getMainActivity().addScore(
									cardMap[x][y].getNum());
							isMove = true;
						}
						break;
					}
				}
			}
		}
		if (isMove) {
			addRandom();
			checkGameEnd();
		}

	}

	private int ltionStartX;
	private int ltionEndX;
	private int width;

	/**
	 * 向右移动
	 */
	protected void rigthMove() {
		boolean isMove = false;
		for (int y = 3; y >= 0; y--) {
			for (int x = 3; x >= 0; x--) {

				for (int x1 = x - 1; x1 >= 0; x1--) {

					if (cardMap[x1][y].getNum() > 0) {
						if (cardMap[x][y].getNum() <= 0) {

							cardMap[x][y].setNum(cardMap[x1][y].getNum());
							cardMap[x1][y].setNum(0);

							x++;
							isMove = true;
						} else if (cardMap[x][y].equals(cardMap[x1][y])) {
							cardMap[x][y].setNum(cardMap[x][y].getNum() * 2);
							cardMap[x1][y].setNum(0);
							MainActivity.getMainActivity().addScore(
									cardMap[x][y].getNum());
							isMove = true;
						}
						break;
					}
				}

			}
		}
		if (isMove) {
			addRandom();
			checkGameEnd();
		}
	}

	/**
	 * 想左移动
	 */
	protected void leftMove() {
		boolean isMove = false;
		float locationX;

		for (int y = 0; y < 4; y++) {
			for (int x = 0; x < 4; x++) {

				for (int x1 = x + 1; x1 < 4; x1++) {

					if (cardMap[x1][y].getNum() > 0) {

						if (cardMap[x][y].getNum() <= 0) {

							cardMap[x][y].setNum(cardMap[x1][y].getNum());
							cardMap[x1][y].setNum(0);
							x--;
							isMove = true;

						} else if (cardMap[x][y].equals(cardMap[x1][y])) {
							cardMap[x][y].setNum(cardMap[x][y].getNum() * 2);
							cardMap[x1][y].setNum(0);

							MainActivity.getMainActivity().addScore(
									cardMap[x][y].getNum());
							isMove = true;
						}
						break;
					}
				}
			}
		}
		if (isMove) {
			addRandom();
			checkGameEnd();
		}
	}

	// 重新计算大小
	@Override
	protected void onSizeChanged(int w, int h, int oldw, int oldh) {
		super.onSizeChanged(w, h, oldw, oldh);
		cardWidth = (Math.min(w, h) - 10) / 4;

		addCard(cardWidth, cardWidth);

		startGame();
	}

	/**
	 * 增加卡片
	 * 
	 * @param cardWidth
	 * @param cardHeight
	 */
	private void addCard(int cardWidth, int cardHeight) {
		Card card;
		for (int y = 0; y < 4; y++) {
			for (int x = 0; x < 4; x++) {
				card = new Card(getContext());
				card.setNum(0);
				addView(card, cardHeight, cardWidth);
				cardMap[x][y] = card;
			}
		}

	}

	/**
	 * 开始游戏
	 */
	private void startGame() {

		MainActivity.getMainActivity().clearScore(); // 清空成绩
		for (int y = 0; y < 4; y++) {
			for (int x = 0; x < 4; x++) {
				cardMap[x][y].setNum(0); // 默认值位置 不显示文本
			}
		}
		// 增加两个数字
		addRandom();
		addRandom();
	}

	/**
	 * 增加数字
	 */
	private void addRandom() {
		emptypoint.clear();
		for (int y = 0; y < 4; y++) {
			for (int x = 0; x < 4; x++) {
				if (cardMap[x][y].getNum() <= 0) {
					emptypoint.add(new Point(x, y));
				}
			}
		}
		Point point = emptypoint.remove((int) (Math.random() * emptypoint
				.size()));
		cardMap[point.x][point.y].setNum(Math.random() > 0.1 ? 2 : 4); // 有1:9的概率增加4和2
	}

	/**
	 * 检查游戏结束
	 */
	private void checkGameEnd() {

		boolean isGameEnd = true;

		ALL: // 由于break只能跳出一个For循环，因此使用ALL：标记使break全部跳出
		for (int y = 0; y < 4; y++) {
			for (int x = 0; x < 4; x++) {

				if (cardMap[x][y].getNum() == 0
						|| (x > 0 && cardMap[x][y].equals(cardMap[x - 1][y]))
						|| (x < 3 && cardMap[x][y].equals(cardMap[x + 1][y]))
						|| (y > 0 && cardMap[x][y].equals(cardMap[x][y - 1]))
						|| (y < 3 && cardMap[x][y].equals(cardMap[x][y + 1]))) {
					isGameEnd = false;
					break ALL;
				}
			}

		}

		if (isGameEnd) {
			new AlertDialog.Builder(getContext())
					.setTitle("你好")
					.setMessage("游戏结束!")
					.setPositiveButton("再玩一局",
							new DialogInterface.OnClickListener() {

								@Override
								public void onClick(DialogInterface dialog,
										int which) {
									startGame();
								}
							})
					.setNegativeButton("退出",
							new DialogInterface.OnClickListener() {

								@Override
								public void onClick(DialogInterface dialog,
										int which) {
									MainActivity.getMainActivity().finish();
								}
							}).show();
		}
	}
}
