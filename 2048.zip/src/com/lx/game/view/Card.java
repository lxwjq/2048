package com.lx.game.view;

import android.content.Context;
import android.graphics.Color;
import android.util.AttributeSet;
import android.view.Gravity;
import android.widget.FrameLayout;
import android.widget.TextView;

public class Card extends FrameLayout {

	private int num;
	private TextView label;
	private String mBgColor = "#EEE4DA";

	public Card(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		initView();
	}

	public Card(Context context, AttributeSet attrs) {
		super(context, attrs);
		initView();
	}

	public Card(Context context) {
		super(context);
		initView();
	}

	private void initView() {
		label = new TextView(getContext());
		label.setTextSize(30);
		label.setGravity(Gravity.CENTER);
		label.setBackgroundColor(Color.parseColor(mBgColor));
		LayoutParams params = new LayoutParams(-1, -1);
		params.setMargins(10, 10, 0, 0);
		addView(label, params);
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;

		switch (num) {
		case 0:
			mBgColor = "#CCC0B3";
			break;
		case 2:
			mBgColor = "#EEE4DA";
			break;
		case 4:
			mBgColor = "#EDE0C8";
			break;
		case 8:
			mBgColor = "#F2B179";// #F2B179
			break;
		case 16:
			mBgColor = "#F49563";
			break;
		case 32:
			mBgColor = "#F5794D";
			break;
		case 64:
			mBgColor = "#F55D37";
			break;
		case 128:
			mBgColor = "#EEE863";
			break;
		case 256:
			mBgColor = "#EDB04D";
			break;
		case 512:
			mBgColor = "#ECB04D";
			break;
		case 1024:
			mBgColor = "#EB9437";
			break;
		case 2048:
			mBgColor = "#EA7821";
			break;
		default:
			mBgColor = "#EA7821";
			break;
		}
		label.setBackgroundColor(Color.parseColor(mBgColor));
		if (num <= 0) {
			label.setText("");
		} else {
			label.setText(String.valueOf(num));
		}
	}

	public boolean equals(Card card) {
		return getNum() == card.getNum();
	}
}
